<h1>Add Form</h1>
<form action="process/process_add.php" method="POST">
    Name : <input type="text" name="txt_name">
    <br>
    NickName : <input type="text" name="txt_nickname">
    <br>
    Social : <input type="text" name="txt_social">
    <br>
    Mobile : <input type="text" name="txt_mobile">
    <br>
<input type="submit" value="OK">
<input type="reset" value="Cancel">
</form>